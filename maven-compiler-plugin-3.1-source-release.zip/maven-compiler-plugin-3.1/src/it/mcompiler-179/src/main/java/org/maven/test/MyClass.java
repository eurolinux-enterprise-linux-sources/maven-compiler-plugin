package org.maven.test;

import java.util.ArrayList;
import java.util.List;

public class MyClass {

    public void foo() {
        List blah = new ArrayList();
        blah.add("hello");
    }

    public void bar() {
        int a = "error";
    }
}
