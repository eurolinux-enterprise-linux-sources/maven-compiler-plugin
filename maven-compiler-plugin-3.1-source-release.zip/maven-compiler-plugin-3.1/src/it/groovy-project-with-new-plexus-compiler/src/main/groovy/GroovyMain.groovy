class GroovyMain {
	static void main(String... args) {
		new GroovyHello().sayHello()
	}
}