class GroovyHello implements Helloable {
	void sayHello() {
		println("Hello World from Groovy!")
	}
}