/**
 * dumb test bean
 */
public class BeanA {

    private int i,y;

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }
}
