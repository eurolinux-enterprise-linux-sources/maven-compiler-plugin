/**
 * dumb test bean
 */
public class BeanA2 {

    private int i;
    private BeanA beanA;

    public int getI() {
        return beanA.getI();
    }

    public void setI(int i) {
        beanA.setI(i);
    }
}
