package org.maven.test;
import java.util.ArrayList;
import java.util.List;



public class Main {
    /**
     * @param args
     */
    public static void main(String[] args) {
        List blah = new ArrayList();
        blah.add("hello");
    }
}
